readme.txt

The directory contains the source code for the
Dale/Joyce/Weems textbook Object-Oriented Data
Structures using Java.

We suggest you copy the entire directory
to the hard drive of the computer you use to do
Java programming. This will ensure easy access to 
all the files and will maintain the crucial 
subdirectory structure required by the various
packages. Make sure you extend your computer's
ClassPath to include your new directory.

For more information see the feature section on
packages in Chapter Two of the textbook.