package ch09.circles;

public class Circle
{
  public int xValue;
  public int yValue;
  public float radius;
  public boolean solid;

} // class Circle
