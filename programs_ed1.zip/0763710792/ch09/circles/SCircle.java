package ch09.circles;

import java.io.*;

public class SCircle implements Serializable
{
  public int xValue;
  public int yValue;
  public float radius;
  public boolean solid;
} 
