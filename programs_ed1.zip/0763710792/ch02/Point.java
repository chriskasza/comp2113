public class Point
{
  public int xValue;
  public int yValue;

} // class Point
