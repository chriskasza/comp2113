public class NewCircle
{
  public Point location;
  public float radius;
  public boolean solid;

} // class NewCircle
